<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validação do CPF e do CNPJ</title>
</head>
<body>
    <h3>Validação do CPF e do CNPJ</h3>
    <?php
    require "validar.php";
    $cpf = "025.108.485-10";
    if(validaCPF($cpf))
    echo "CPF é válido!";
    else
    echo "CPF é inválido";
    $cnpj = "59 456 277/0001-76";
    if(validarCNPJ($cnpj))
    echo "CNPJ é válido!";
    else
    echo "CNPJ é inválido";
    ?>
</body>
</html>