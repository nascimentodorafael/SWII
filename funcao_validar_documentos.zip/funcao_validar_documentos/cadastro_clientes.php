<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Clientes em PHP</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <div class="container">
        <h3>Cadastro Clientes em PHP</h3>
        <form name="login" method="post" action="">
            <div class="form-group"> 
                <label for="nome">Nome:</label>
                <input type="text" name="nome" required>
            </div>
            <div class="form-group">
                <label for="cidade">Cidade:</label>
                <input type="text" name="cidade" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" name="email" required>
            </div>
            <div class="form-group">
                <label for="cpf">CPF:</label>
                <input type="number" name="cpf" required>
            </div>
            <div class="form-group">
                <label for="rg">RG:</label>
                <input type="number" name="rg" required>
            </div>
            <div class="form-group">
                <label for="contato">Contato:</label>
                <input type="number" name="contato" required>
            </div>
            <input type="submit" value="Cadastrar" name="cadastrar">
        </form>
        <p align="center"><a href="index.php">Efetuar Login</a></p>
    </div>
    <?php
        if(isset($_POST["cadastrar"]))
        {
            $nome      =     $_POST["nome"];
            $cidade    =     $_POST["cidade"];
            $email     =     $_POST["email"];
            $cpf       =     $_POST["cpf"];
            $rg        =     $_POST["rg"];
            $contato   =     $_POST["cpf"];

            if($senha == $confSenha)
            {
                require "conexao.php";
                $sql="INSERT INTO usuario (codigo,nome,usuario,senha)";
                $sql.=" VALUES (null, '$nome','$usuario','$senha')";
                mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
                echo "<p align='center'>Conta cadastrada com sucesso!</p>";
            }
            else    
            {
                echo "<p align='center'>A senha de confirmação está inválida!</p>";
            }
        }
    ?>
</body>
</html>