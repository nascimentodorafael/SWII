<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Fornecedores em PHP</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <div class="container">
        <h3>Cadastro de Fornecedores em PHP</h3>
        <form name="login" method="post" action="">
        <div class="form-group"> 
                <label for="razaosocial">Razão Social:</label>
                <input type="text" name="razaosocial" required>
            </div>
            <div class="form-group"> 
                <label for="nomefantasia">Nome Fantasia:</label>
                <input type="text" name="nomefantasia" required>
            </div>
            <div class="form-group">
                <label for="cidade">Cidade:</label>
                <input type="text" name="cidade" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" name="email" required>
            </div>
            <div class="form-group">
                <label for="cnpj">CNPJ:</label>
                <input type="number" name="cnpj" required>
            </div>
            <div class="form-group">
                <label for="inscricaoestadual">Inscrição Estadual:</label>
                <input type="number" name="inscricaoestadual" required>
            </div>
            <div class="form-group">
                <label for="contato">Contato:</label>
                <input type="number" name="contato" required>
            </div>
            <input type="submit" value="Cadastrar" name="cadastrar">
        </form>
        <p align="center"><a href="index.php">Efetuar Login</a></p>
    </div>
    <?php
        if(isset($_POST["cadastrar"]))
        {
            $razaosocial       = $_POST["razaosocial"];
            $nomefantasia      = $_POST["nome"];
            $cidade            = $_POST["cidade"];
            $email             = $_POST["email"];
            $cnpj              = $_POST["cnpj"];
            $inscricaoestadual = $_POST["inscricaoestadual"];
            $contato           = $_POST["cpf"];

            if($senha == $confSenha)
            {
                require "conexao.php";
                $sql="INSERT INTO usuario (codigo,nome,usuario,senha)";
                $sql.=" VALUES (null, '$nome','$usuario','$senha')";
                mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
                echo "<p align='center'>Conta cadastrada com sucesso!</p>";
            }
            else    
            {
                echo "<p align='center'>A senha de confirmação está inválida!</p>";
            }
        }
    ?>
</body>
</html>